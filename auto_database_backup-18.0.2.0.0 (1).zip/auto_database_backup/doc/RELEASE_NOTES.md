## Module <auto_database_backup>

#### 30.09.2024
#### Version 18.0.1.0.0
#### ADD

- Initial commit for Automatic Database Backup To Local Server, Remote Server, Google Drive, Dropbox, Onedrive, Nextcloud and Amazon S3 Odoo18.

#### 29.10.2024
#### Version 18.0.2.0.0
#### UPDT

- Added feature to set Multi-Level Backup Storage, Store backups in multiple locations based on different intervals. 
