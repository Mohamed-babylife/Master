## Module <responsive_web>
#### 04.09.2024
#### Version 17.0.1.0.0
#### ADD
- Initial commit for Web Responsive

#### 16.10.2024
#### Version 17.0.1.0.1
##### BUG FIX
- Fixed the scrolling issue in mobile screens