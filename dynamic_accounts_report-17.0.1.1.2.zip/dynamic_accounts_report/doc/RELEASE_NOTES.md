## Module <dynamic_accounts_report>

#### 12.12.2023
#### Version 17.0.1.0.0
#### ADD
- Initial commit for Dynamic Accounts  Reports

#### 16.04.2024
#### Version 17.0.1.0.1
##### BUG FIX
- Updated the Dynamic Balance sheet Reporting 

#### 10.07.2024
#### Version 17.0.1.1.1
##### BUG FIX
- Added the initial balance in partner ledger (xlsx and PDF)
